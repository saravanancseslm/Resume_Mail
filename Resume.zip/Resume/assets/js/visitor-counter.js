(function () {
    var WEB3FORMS_KEY = 'e9946af9-6597-4104-8d36-3996d8be0ae9';
    var OWNER_EMAIL = 'saravanan6641@gmail.com';
    var NAMESPACE = 'saravanan-resume-portfolio';
    var TOTAL_KEY = 'total-page-views';
    var UNIQUE_KEY = 'unique-visitors';
    var VISITOR_FLAG_KEY = 'saravanan-resume-visitor-tracked';
    var SESSION_MAIL_KEY = 'saravanan-visit-mail-sent';
    var VISITOR_EMAIL_KEY = 'saravanan-visitor-email';
    var EMAIL_PROMPT_KEY = 'saravanan-email-prompt-done';
    var API_BASE = 'https://api.countapi.xyz';
    var TIMEOUT_MS = 8000;

    function formatCount(value) {
        if (value == null || isNaN(value)) {
            return '—';
        }
        return Number(value).toLocaleString();
    }

    function updateDisplay(total, unique) {
        document.querySelectorAll('[data-visitor-total]').forEach(function (el) {
            el.textContent = formatCount(total);
        });
        document.querySelectorAll('[data-visitor-unique]').forEach(function (el) {
            el.textContent = formatCount(unique);
        });
    }

    function getPageName() {
        var page = window.location.pathname.split('/').pop();

        if (!page || page === '' || page === 'index.html') {
            return 'Resume Home Page';
        }

        if (page === 'projects.html') {
            return 'Projects Page';
        }

        return page;
    }

    function getVisitDateTime() {
        var now = new Date();
        return {
            date: now.toLocaleDateString('en-IN', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            }),
            time: now.toLocaleTimeString('en-IN', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            })
        };
    }

    function getVisitorEmail() {
        return sessionStorage.getItem(VISITOR_EMAIL_KEY) || localStorage.getItem(VISITOR_EMAIL_KEY) || 'Not shared';
    }

    function parseUserAgent() {
        var ua = navigator.userAgent || '';
        var info = {
            deviceType: 'Desktop',
            deviceName: 'Unknown device',
            os: 'Unknown OS',
            browser: 'Unknown browser'
        };

        if (/mobile|android|iphone|ipod|blackberry|iemobile|opera mini/i.test(ua)) {
            info.deviceType = 'Mobile';
        } else if (/ipad|tablet|playbook|silk/i.test(ua)) {
            info.deviceType = 'Tablet';
        }

        if (/iphone/i.test(ua)) {
            info.deviceName = 'Apple iPhone';
        } else if (/ipad/i.test(ua)) {
            info.deviceName = 'Apple iPad';
        } else if (/ipod/i.test(ua)) {
            info.deviceName = 'Apple iPod';
        } else if (/samsung/i.test(ua)) {
            info.deviceName = 'Samsung device';
        } else if (/pixel/i.test(ua)) {
            info.deviceName = 'Google Pixel';
        } else if (/huawei/i.test(ua)) {
            info.deviceName = 'Huawei device';
        } else if (/oneplus/i.test(ua)) {
            info.deviceName = 'OnePlus device';
        } else if (/xiaomi|redmi/i.test(ua)) {
            info.deviceName = 'Xiaomi / Redmi device';
        } else if (/android/i.test(ua)) {
            info.deviceName = 'Android device';
        } else if (/macintosh|mac os x/i.test(ua)) {
            info.deviceName = 'Apple Mac';
        } else if (/windows/i.test(ua)) {
            info.deviceName = 'Windows PC';
        } else if (/linux/i.test(ua)) {
            info.deviceName = 'Linux device';
        }

        if (/windows nt 10/i.test(ua)) {
            info.os = 'Windows 10/11';
        } else if (/windows nt 6.3/i.test(ua)) {
            info.os = 'Windows 8.1';
        } else if (/windows nt 6.1/i.test(ua)) {
            info.os = 'Windows 7';
        } else if (/android ([\d.]+)/i.test(ua)) {
            info.os = 'Android ' + ua.match(/android ([\d.]+)/i)[1];
        } else if (/os ([\d_]+) like mac os x/i.test(ua)) {
            info.os = 'iOS ' + ua.match(/os ([\d_]+) like mac os x/i)[1].replace(/_/g, '.');
        } else if (/mac os x ([\d_]+)/i.test(ua)) {
            info.os = 'macOS ' + ua.match(/mac os x ([\d_]+)/i)[1].replace(/_/g, '.');
        } else if (/linux/i.test(ua)) {
            info.os = 'Linux';
        }

        if (/edg\/([\d.]+)/i.test(ua)) {
            info.browser = 'Microsoft Edge ' + ua.match(/edg\/([\d.]+)/i)[1];
        } else if (/chrome\/([\d.]+)/i.test(ua) && !/edg/i.test(ua)) {
            info.browser = 'Google Chrome ' + ua.match(/chrome\/([\d.]+)/i)[1];
        } else if (/firefox\/([\d.]+)/i.test(ua)) {
            info.browser = 'Mozilla Firefox ' + ua.match(/firefox\/([\d.]+)/i)[1];
        } else if (/version\/([\d.]+).*safari/i.test(ua)) {
            info.browser = 'Safari ' + ua.match(/version\/([\d.]+).*safari/i)[1];
        } else if (/opr\/([\d.]+)/i.test(ua)) {
            info.browser = 'Opera ' + ua.match(/opr\/([\d.]+)/i)[1];
        }

        return info;
    }

    function getDeviceDetails() {
        var parsed = parseUserAgent();
        var connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
        var details = {
            'Device Name': parsed.deviceName,
            'Device Type': parsed.deviceType,
            'Operating System': parsed.os,
            'Browser': parsed.browser,
            'Platform': navigator.platform || 'Unknown',
            'Language': navigator.language || 'Unknown',
            'Languages': (navigator.languages || []).join(', ') || 'Unknown',
            'Timezone': Intl.DateTimeFormat().resolvedOptions().timeZone || 'Unknown',
            'Screen Size': window.screen.width + ' x ' + window.screen.height,
            'Viewport Size': window.innerWidth + ' x ' + window.innerHeight,
            'Pixel Ratio': window.devicePixelRatio || 1,
            'CPU Cores': navigator.hardwareConcurrency || 'Unknown',
            'Device Memory': navigator.deviceMemory ? navigator.deviceMemory + ' GB' : 'Unknown',
            'Touch Support': navigator.maxTouchPoints > 0 ? 'Yes' : 'No',
            'Online Status': navigator.onLine ? 'Online' : 'Offline',
            'Connection': connection && connection.effectiveType ? connection.effectiveType : 'Unknown',
            'Vendor': navigator.vendor || 'Unknown',
            'User Agent': navigator.userAgent || 'Unknown'
        };

        return details;
    }

    function buildVisitMessage(pageName) {
        var visit = getVisitDateTime();
        var device = getDeviceDetails();
        var lines = [
            'Hello Saravanan,',
            '',
            'Someone has visited your resume profile.',
            '',
            'Date: ' + visit.date,
            'Time: ' + visit.time,
            'Page: ' + pageName,
            'Visitor Email: ' + getVisitorEmail(),
            '',
            '--- Device Details ---'
        ];

        Object.keys(device).forEach(function (key) {
            lines.push(key + ': ' + device[key]);
        });

        return lines.join('\n');
    }

    function sendVisitEmail(pageName, keepalive) {
        var visit = getVisitDateTime();
        var visitorEmail = getVisitorEmail();
        var formData = new FormData();
        formData.append('access_key', WEB3FORMS_KEY);
        formData.append('subject', 'Resume Visited - ' + visit.date + ' at ' + visit.time);
        formData.append('from_name', 'Portfolio Visitor Alert');
        formData.append('name', 'Website Visitor');
        formData.append('email', visitorEmail !== 'Not shared' ? visitorEmail : OWNER_EMAIL);
        formData.append('message', buildVisitMessage(pageName));

        return fetch('https://api.web3forms.com/submit', {
            method: 'POST',
            body: formData,
            headers: {
                'Accept': 'application/json'
            },
            keepalive: !!keepalive
        }).then(function (response) {
            if (!response.ok) {
                throw new Error('Unable to send visit notification.');
            }
            return response.json();
        }).then(function (data) {
            if (!data.success) {
                throw new Error(data.message || 'Visit notification failed.');
            }
            return data;
        }).catch(function (error) {
            console.warn('Visit email failed:', error);
        });
    }

    function saveVisitorEmail(email) {
        sessionStorage.setItem(VISITOR_EMAIL_KEY, email);
        localStorage.setItem(VISITOR_EMAIL_KEY, email);
    }

    function showEmailPrompt() {
        if (localStorage.getItem(EMAIL_PROMPT_KEY) || localStorage.getItem(VISITOR_EMAIL_KEY)) {
            return;
        }

        var panel = document.createElement('div');
        panel.className = 'visitor-email-prompt';
        panel.innerHTML =
            '<div class="visitor-email-prompt-content">' +
                '<button type="button" class="visitor-email-close" aria-label="Close">&times;</button>' +
                '<h4>Welcome!</h4>' +
                '<p>Share your email (optional) so Saravanan knows who visited.</p>' +
                '<input type="email" class="visitor-email-input" placeholder="your.email@example.com">' +
                '<div class="visitor-email-actions">' +
                    '<button type="button" class="visitor-email-submit">Share Email</button>' +
                    '<button type="button" class="visitor-email-skip">Skip</button>' +
                '</div>' +
            '</div>';

        document.body.appendChild(panel);

        function closePrompt() {
            localStorage.setItem(EMAIL_PROMPT_KEY, '1');
            if (panel.parentNode) {
                panel.parentNode.removeChild(panel);
            }
        }

        panel.querySelector('.visitor-email-close').addEventListener('click', closePrompt);
        panel.querySelector('.visitor-email-skip').addEventListener('click', closePrompt);

        panel.querySelector('.visitor-email-submit').addEventListener('click', function () {
            var input = panel.querySelector('.visitor-email-input');
            var email = (input.value || '').trim();

            if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                input.focus();
                return;
            }

            saveVisitorEmail(email);
            closePrompt();
            sendVisitEmail('Visitor shared email on ' + getPageName(), false);
        });
    }

    function fetchWithTimeout(url) {
        return Promise.race([
            fetch(url),
            new Promise(function (_, reject) {
                setTimeout(function () {
                    reject(new Error('Counter request timed out'));
                }, TIMEOUT_MS);
            })
        ]);
    }

    function counterRequest(action, key) {
        return fetchWithTimeout(API_BASE + '/' + action + '/' + NAMESPACE + '/' + key)
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('Counter request failed');
                }
                return response.json();
            })
            .then(function (data) {
                return data.value;
            });
    }

    function updateVisitorCounts() {
        var isNewVisitor = !localStorage.getItem(VISITOR_FLAG_KEY);
        var totalPromise = counterRequest('hit', TOTAL_KEY);
        var uniquePromise = isNewVisitor
            ? counterRequest('hit', UNIQUE_KEY).then(function (value) {
                localStorage.setItem(VISITOR_FLAG_KEY, '1');
                return value;
            })
            : counterRequest('get', UNIQUE_KEY);

        return Promise.all([totalPromise, uniquePromise])
            .then(function (counts) {
                updateDisplay(counts[0], counts[1]);
            })
            .catch(function () {
                updateDisplay(null, null);
            });
    }

    function notifyVisit(pageName, keepalive) {
        sendVisitEmail(pageName, keepalive);
    }

    function onPageVisit() {
        updateVisitorCounts();

        if (!sessionStorage.getItem(SESSION_MAIL_KEY)) {
            sessionStorage.setItem(SESSION_MAIL_KEY, '1');
            notifyVisit(getPageName(), false);
        }

        setTimeout(showEmailPrompt, 2500);
    }

    function onLinkClick(event) {
        var link = event.target.closest('a[href]');

        if (!link) {
            return;
        }

        var href = link.getAttribute('href');

        if (!href || href === '#' || href.indexOf('javascript:') === 0) {
            return;
        }

        var linkText = (link.textContent || '').replace(/\s+/g, ' ').trim() || href;
        var pageName = 'Clicked: ' + linkText;

        notifyVisit(pageName, true);
    }

    function init() {
        updateDisplay(null, null);
        onPageVisit();
        document.addEventListener('click', onLinkClick, true);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
