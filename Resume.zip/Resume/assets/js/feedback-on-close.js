(function () {
    var feedbackCompleted = false;
    var allowInternalNavigation = false;
    var pageReadyAt = Date.now();
    var FEEDBACK_DONE_KEY = 'saravanan-feedback-completed';

    function hasCompletedFeedback() {
        return feedbackCompleted || sessionStorage.getItem(FEEDBACK_DONE_KEY) === '1';
    }

    function markFeedbackCompleted() {
        feedbackCompleted = true;
        sessionStorage.setItem(FEEDBACK_DONE_KEY, '1');
    }

    function isFeedbackOpen() {
        var modal = document.getElementById('feedbackModal');
        return modal && (modal.classList.contains('in') || modal.classList.contains('show'));
    }

    function showFeedbackModal() {
        if (hasCompletedFeedback() || allowInternalNavigation || isFeedbackOpen()) {
            return;
        }

        if (window.jQuery) {
            window.jQuery('#feedbackModal').modal('show');
        }
    }

    function isInternalSiteLink(href) {
        if (!href) {
            return false;
        }

        if (href.charAt(0) === '#' || href.indexOf('javascript:') === 0) {
            return true;
        }

        try {
            var url = new URL(href, window.location.href);
            var path = url.pathname.toLowerCase();
            var sameSite = url.origin === window.location.origin;
            var isSitePage = sameSite && (
                /\/(index\.html|projects\.html)?$/i.test(path) ||
                path.indexOf('/assets/html/') !== -1 ||
                path.indexOf('/assets/download/') !== -1
            );
            return isSitePage;
        } catch (error) {
            return href.indexOf('projects.html') !== -1 || href.indexOf('index.html') !== -1;
        }
    }

    function submitFormData(formData) {
        return fetch('https://api.web3forms.com/submit', {
            method: 'POST',
            body: formData,
            headers: {
                Accept: 'application/json'
            }
        }).then(function (response) {
            if (!response.ok) {
                throw new Error('HTTP error! status: ' + response.status);
            }
            return response.json();
        });
    }

    function handleFormSubmission(form) {
        var submitButton = document.getElementById('submitFeedback');
        var originalText = submitButton.innerHTML;

        submitButton.innerHTML = 'Submitting...';
        submitButton.disabled = true;

        var formData = new FormData(form);
        formData.append('timestamp', new Date().toISOString());

        submitFormData(formData)
            .then(function (data) {
                if (!data.success) {
                    throw new Error(data.message || 'Submission failed');
                }

                alert('Thank you for your feedback!');
                form.reset();
                markFeedbackCompleted();
                if (window.jQuery) {
                    window.jQuery('#feedbackModal').modal('hide');
                }
            })
            .catch(function (error) {
                console.error('Feedback submit error:', error);
                alert('Error submitting feedback: ' + (error.message || 'Please try again later.'));
            })
            .then(function () {
                submitButton.innerHTML = originalText;
                submitButton.disabled = false;
            });
    }

    function validateAndSubmit() {
        var form = document.getElementById('feedbackForm');
        var name = document.getElementById('visitorName').value;
        var email = document.getElementById('visitorEmail').value;
        var ratingEl = document.querySelector('input[name="rating"]:checked');
        var rating = ratingEl ? ratingEl.value : '';
        var feedback = document.getElementById('feedbackMessage').value;

        if (!name || !email || !rating || !feedback) {
            alert('Please fill in all required fields (Name, Email, Rating, and Feedback)');
            return;
        }

        handleFormSubmission(form);
    }

    function bindEvents() {
        document.addEventListener('click', function (event) {
            var link = event.target.closest('a[href]');
            if (!link) {
                return;
            }

            if (isInternalSiteLink(link.getAttribute('href')) || isInternalSiteLink(link.href)) {
                allowInternalNavigation = true;
            }
        }, true);

        document.addEventListener('mouseout', function (event) {
            if (hasCompletedFeedback() || allowInternalNavigation) {
                return;
            }

            if (Date.now() - pageReadyAt < 1500) {
                return;
            }

            if (event.relatedTarget || event.toElement) {
                return;
            }

            if (event.clientY > 12) {
                return;
            }

            showFeedbackModal();
        });

        window.addEventListener('beforeunload', function (e) {
            if (allowInternalNavigation || hasCompletedFeedback()) {
                return;
            }

            setTimeout(function () {
                allowInternalNavigation = false;
                showFeedbackModal();
            }, 300);

            e.preventDefault();
            e.returnValue = 'Please share your feedback before leaving.';
            return e.returnValue;
        });

        var submitButton = document.getElementById('submitFeedback');
        var form = document.getElementById('feedbackForm');

        if (submitButton) {
            submitButton.addEventListener('click', function (e) {
                e.preventDefault();
                validateAndSubmit();
            });
        }

        if (form) {
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                validateAndSubmit();
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bindEvents);
    } else {
        bindEvents();
    }
})();
